<html>
    <head>
        <title>teste</title>
    </head>
    <body>
      <?php
      for($i = 1; $i <= 100; $i++) {
                $teste[$i] = $i;
            }

            for($i = 3; $i <= 100; $i+=3) {
                $teste[$i] = "Linio";
            }

            for($i = 5; $i <= 100; $i+=5) {

                $teste[$i] = "IT";
            }

            for($i = 5; $i <= 100; $i+=5) {
      		if($i % 3 == 0)
                $teste[$i] = "Linianos";
            }


            foreach ($teste as $result) {
                print "<br>" . $result . ' ';
            }
            ?>
    </body>
</html>
